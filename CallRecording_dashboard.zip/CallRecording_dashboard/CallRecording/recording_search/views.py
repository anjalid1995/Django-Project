from django.shortcuts import render
import os
from django.http import HttpResponse

# Create your views here.

def login(request):
    return render(request,'login.html')


def select_process(request):
    list_call = os.listdir(r'D:\CallRecording_dashboard\CallRecording\recording_search\media\audio')
    list_files = []
    for name in list_call:
        list_files.append(name)
    return render(request,'select_process.html', {'all_audio': list_files[:10]})

def audio_analyses(request,a):

    return render(request,'audio_analyses.html',{'a': a})
