from django.apps import AppConfig


class RecordingSearchConfig(AppConfig):
    name = 'recording_search'
