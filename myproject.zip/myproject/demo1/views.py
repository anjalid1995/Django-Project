from django.db import Error
import pandas as pd
from datetime import datetime
import urllib.request
import os
from django.http import HttpResponseRedirect, HttpResponse, request, Http404
from django.shortcuts import render
import sqlite3
from django.contrib.auth import authenticate, login
from django.contrib import auth
# Create your views here.
# from django.http import HttpResponse
from django.shortcuts import render
from django.conf import settings
from django.core.files.storage import FileSystemStorage, default_storage
import re
from django.views.static import serve
import openpyxl

#database connection
def connection():
    database  = "D:/myproject/myproject.sqlite3"
    try:
        conn = sqlite3.connect(database)
    except Error as e1:
        print(e1)
    return conn


def connection1():
    database  = "D:/flipkart_crm.sqlite3"
    try:
        conn = sqlite3.connect(database)
    except Error as e1:
        print(e1)

    return conn

#download file
def download_file(request):
    data1 = pd.read_sql_query("SELECT walmart_raw.catlg_item_id, walmart_raw.type, assign_data.status,assign_data.assigned_time from walmart_raw LEFT JOIN assign_data ON walmart_raw.id = assign_data.raw_id",
        connection1())
    filename = 'new.xlsx' #name which we want to assign
    data1.to_excel(filename, 'data1', index=False)
    if os.path.exists(filename):
        with open(filename, 'rb') as fh:
             response = HttpResponse(fh.read(), content_type="application/vnd.ms-excel")
             response['Content-Disposition'] = 'inline; filename=' + os.path.basename(filename)
             return response
    raise Http404
    #return serve(request, os.path.basename(filename), os.path.dirname(filename))

def home(request):
    # text = """<h1>welcome to my app !</h1>"""
    return render(request, "home.html")

def register(request):
 #abc={"n1":"Anjali","n2":"abc"}
 return render(request, 'register.html', )

def user_create(request):
    email = request.POST.dict().get("email")
    print(email)
    password1 = request.POST.dict().get("psw")
    password2 = request.POST.dict().get("psw-repeat")
    conn = connection()
    cursor = conn.cursor()
    try:
        cursor.execute("INSERT INTO register (Email, Password , 'Repeat Password') values ('" + str(email) + "', '" + str(
            password1) + "', '" + str(password2) + "')")
        conn.commit()
    except:
        return render(request, 'register.html', {'exist': 'User Already Exist'})
    return home(request)

def login(request):
 email = request.email
 return render(request,'login.html',{'email': email})

def user_stats(request):
    timestamp = datetime.now().strftime('%Y-%m-%d %H:%M:%S')
    email = request.POST.dict().get("email")
    conn = connection()
    cursor = conn.cursor()
    cursor.execute("INSERT INTO user_stats (email, login_time ) values ('" + str(email) + "', '" + str(timestamp) + "')")
    conn.commit()
    return home(request)

def login_tb(request):
    timestamp = datetime.now().strftime('%Y-%m-%d %H:%M:%S')
    conn=connection()
    cursor = conn.cursor()
    email = request.POST.dict().get("email")
    password = request.POST.dict().get("psw")
    id_pass = pd.read_sql_query("SELECT count(email) as Count from register where email = '"+str(email)+"' and password = '"+str(password)+"'", conn)
    x=id_pass['Count'][0]

    if(x > 0):
     db_email = pd.read_sql_query("select email from user_stats where email = '"+str(email)+"' ",conn)
     print("select email from user_stats where email = '"+str(email)+"'")
     x1=db_email['email']
     if (email not in list(x1)):
        cursor.execute("INSERT INTO user_stats (email, login_time ) values ('" + str(email) + "', '" + str(timestamp) + "')")
        conn.commit()
        request.email = email
        request.session['email'] = email
        return login(request)
     else:
         request.email = email
         session_set="your session is set"
         print(session_set)
         request.session['email'] = email
         return login(request)
    else:
      wrong = "Wrong Username or Password"
      return render(request, 'home.html', {'wrong': wrong})

def registered(request):
 conn = connection()
    #cursor = conn.cursor()
 db1= pd.read_sql_query("SELECT * FROM register",conn)
 conn.commit()
    #db1=pd.read_sql_query("select * from register")
 db1=db1.to_html()
 return render(request,'registered.html',{'db1':db1})

def terms(request):
    return render(request,'terms.html',)

def logout(request):
        del request.session['email']
        return render(request,'logout.html')

def about(request):
    if request.session.has_key('email'):
        return render(request,'about.html',)
    else:
        return render(request,'home.html',)

def simple_upload(request):
    file = request.FILES['file']
    file_name = default_storage.save('simple.sqlite3', file)
    return render(request, 'home.html')

def index1(request):
    return render(request,'index.html')