from django.apps import AppConfig


class Demo1Config(AppConfig):
    name = 'demo1'
