from django.db import models

# Create your models here.
from django.db import models

class Dreamreal(models.Model):
   mail = models.CharField(max_length = 50)
   name = models.CharField(max_length = 50)
   password=models.CharField(max_length = 8)
   phonenumber = models.IntegerField()

   class Meta:
      db_table = "dreamreal"